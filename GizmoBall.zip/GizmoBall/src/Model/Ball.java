package Model;

public class Ball {
}
