package Model;

public class Absorber implements IGizmo{
}
