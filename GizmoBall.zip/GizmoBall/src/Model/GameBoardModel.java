package Model;

public class GameBoardModel {
}
