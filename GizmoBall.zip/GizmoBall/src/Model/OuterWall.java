package Model;

public class OuterWall {
}
