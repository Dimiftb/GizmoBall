package Model;

public class Flipper implements IGizmo {
}
