package Model;

public class Triangle implements IGizmo {
}
