package Model;

public class Square implements IGizmo{

}
