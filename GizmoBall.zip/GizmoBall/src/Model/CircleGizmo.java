package Model;

public class CircleGizmo implements IGizmo {
}
