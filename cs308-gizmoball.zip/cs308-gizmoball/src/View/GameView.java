package View;

import Controller.RunListener;
import Model.GameBoardModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class GameView extends JFrame {
    private GameBoard gb;
    private BControlPanel cp;

    private GameBoardModel gameBoardModel;


    public GameView(GameBoardModel gm) {
        gameBoardModel = gm;
        gb = new GameBoard(400, 400, gameBoardModel);
        initUI();
    }

    public void initUI() {

        runMOde();
        initComponents();
        setPreferredSize(new Dimension(800, 600));
        setResizable(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("GizmoBall");
        pack();
        setVisible(true);

    }
    private void runMOde() {
        RControlPanel rm = new RControlPanel(gameBoardModel);
        rm.initUI();
        rm.initComponents();
        add(rm, BorderLayout.LINE_START);
    }
    private void buildModePane() {
        BControlPanel bm = new BControlPanel(gameBoardModel);
        bm.initUI();
    }

    private void initComponents() {
        //create panels
        JPanel rightPanel = new JPanel();
        JPanel messagePanel = new JPanel();


        //set panels' attributes
        FlowLayout flowLayout = new FlowLayout();
        BorderLayout borderLayout = new BorderLayout();
        //borderLayout.setVgap(40);
        flowLayout.setVgap(40);


        rightPanel.setLayout(flowLayout);
        rightPanel.setPreferredSize(new Dimension(400, 600));
        rightPanel.setMinimumSize(new Dimension(400, 600));
        rightPanel.setMaximumSize(new Dimension(400, 600));
        //rightPanel.setBackground(Color.MAGENTA);


        messagePanel.setLayout(new FlowLayout());
        messagePanel.setPreferredSize(new Dimension(400, 100));
        messagePanel.setMinimumSize(new Dimension(400, 100));
        messagePanel.setMaximumSize(new Dimension(400, 100));
        messagePanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        //main menu
        JMenuBar mainMenuBar = new JMenuBar();
        mainMenuBar.setBackground(Color.orange);
        JMenu mainMenu = new JMenu("File");
        JMenuItem saveOption = new JMenuItem("Save");
        JMenuItem loadOption = new JMenuItem("Load");
        JMenuItem helpOption = new JMenuItem("Help");
        JMenuItem exitOption = new JMenuItem("Exit");
        mainMenu.add(saveOption);
        mainMenu.add(loadOption);
        mainMenu.add(helpOption);
        mainMenu.add(exitOption);
        mainMenuBar.add(mainMenu);
        setJMenuBar(mainMenuBar);

        ImageIcon playIcon = new ImageIcon("/home/dimiftb/IdeaProjects/GizmoBall/GizmoBall/src/Icons/play.png");
        JButton playButton = new JButton("Play",playIcon);
        playButton.setBackground(Color.ORANGE);
        JLabel messageLabel = new JLabel("Message successfully generated!!");



//        cp.initComponents();
        //add components to frame & panels
        Container contents = getContentPane();
       // contents.add(cp, BorderLayout.LINE_START);
        contents.add(rightPanel, BorderLayout.CENTER);
        contents.add(playButton, BorderLayout.PAGE_END);
        messagePanel.add(messageLabel);
        rightPanel.add(gb);
        rightPanel.add(messagePanel);

    }
}
