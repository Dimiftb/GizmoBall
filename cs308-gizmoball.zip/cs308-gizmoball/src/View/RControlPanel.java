package View;

import Controller.RunListener;
import Model.GameBoardModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class RControlPanel extends JPanel {
    private ActionListener listener;
    private GameBoardModel model;

    public RControlPanel(GameBoardModel gm) {
        model = gm;
        listener = new RunListener(model);

    }

    public void initUI() {

        setPreferredSize(new Dimension(200, 600));
        setLayout(new FlowLayout());
        setBackground(Color.PINK);
    }

    public void initComponents() {
        JPanel controlPanel = new JPanel();


        JButton runButton = new JButton("Run");
        JButton tickButton = new JButton("Tick");
        JButton stopButton = new JButton("Stop");
        runButton.addActionListener(listener);
        tickButton.addActionListener(listener);
        stopButton.addActionListener(listener);
        runButton.setPreferredSize(new Dimension(101,25));
        tickButton.setPreferredSize(new Dimension(101,25));
        stopButton.setPreferredSize(new Dimension(101,25));
        add(runButton);
        add(tickButton);
        add(stopButton);




    }
}
