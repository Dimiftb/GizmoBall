package View;

import Model.Ball;
import Model.GameBoardModel;
import Model.VerticalLine;
import physics.LineSegment;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Observable;
import java.util.Observer;

public class GameBoard extends JPanel implements Observer {

    private int board_width;
    private int board_height;
    private GameBoardModel model;

    public GameBoard(int width, int height, GameBoardModel gm) {
        super();
        board_height = height;
        board_width = width;
        setBackground(Color.WHITE);
        gm.addObserver(this);
        model = gm;
    }

    private void initBoard(GameView parent) {

    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(board_width,board_height);
    }

    private void bPaintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g1 = (Graphics2D) g;
        board_width = getSize().width;
        board_height = getSize().height;
        int rows = 20;
        int columns = 20;
        int rowHeight = board_height/rows;
        int rowWidth = board_width/columns;
        g.setColor(Color.CYAN);
        for(int i = 0; i < rows; i++ ) {
            //rows
            g.drawLine(0,i*rowHeight, board_width, i*rowHeight);
            //columns
            g.drawLine(i *rowWidth,0,i*rowWidth,board_height);
        }
        g.setColor(Color.GREEN);
        g.fillRect(120,180,20,20);
        //flipper
        g.setColor(Color.RED);
        g.fillOval(200,180,20,20);
        g.fillRect(210,180,20,20);
        g.fillRect(230,180,20,20);
        g.fillOval(240,180,20,20);
        int x [] = {160,180,180};
        int y [] = {160,160,180};
        g.setColor(Color.MAGENTA);
        g.fillPolygon(x,y,3);

    }
    private void rPaintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        Ball b = model.getBall();
        for (LineSegment vl : model.getLines()) {
            g2.fillRect((int)vl.p1().x(),(int) vl.p1().x(),(int)vl.p2().x() , 1);
        }
        if (b != null) {
            g2.setColor(b.getColour());
            int x = (int) (b.getxCoord() - b.getRadius());
            int y = (int) (b.getyCoord() - b.getRadius());
            int width = (int) (2 * b.getRadius());
            g2.fillOval(x, y, width, width);
        }
    }



    @Override
    public void paintComponent(Graphics g) {
       rPaintComponent(g);

    }

    @Override
    public void update(Observable arg0, Object arg1) {
        repaint();
    }
}
