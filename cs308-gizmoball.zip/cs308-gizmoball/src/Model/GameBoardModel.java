package Model;


import physics.Circle;
import physics.Geometry;
import physics.LineSegment;
import physics.Vect;

import java.util.ArrayList;
import java.util.Observable;

public class GameBoardModel extends Observable {
    private Ball ball;
    private ArrayList<LineSegment> lines;
    private ArrayList<Circle> circles;
    private Wall wallObject;
    private ArrayList<IGizmo> gizmos;



    public GameBoardModel() {
        lines = new ArrayList<>();
        circles = new ArrayList<>();
        ball = new Ball(25, 25, 100, 100);
        wallObject = new Wall(0, 0, 400, 400);
        System.out.println(wallObject.getLineSegments());

    }

    private CollisionDetails timeUntilCollision() {
        Circle ballCircle = ball.makeCircle();
        Vect ballVelocity = ball.getVelocity();
       ArrayList<LineSegment> wallSegments = wallObject.getLineSegments();
        double time = 0.0;
        double timeTick = Double.MAX_VALUE;
        Vect newVelocity = new Vect(0, 0);
        IGizmo gizmo;
        for (LineSegment wall : wallSegments) {
            time = Geometry.timeUntilWallCollision(wall, ballCircle, ballVelocity);
            if (time < timeTick) {
                timeTick = time;
                newVelocity = Geometry.reflectWall(wall, ball.getVelocity(), 1.0);
            }
        }

        for (LineSegment line : lines) {
            time = Geometry.timeUntilWallCollision(line, ballCircle, ballVelocity);
            //check if condition later on
            if (time < timeTick)
                timeTick = time;
            newVelocity = Geometry.reflectWall(line, ball.getVelocity(), 1.0);
           /* if(line.isATrigger())
                gizmo = line.getGizmo().trigger();   //returns the gizmo that will be activated
                by the trigger
            else
                gizmo = null;
            */
       }
        for (Circle circle : circles) {
            time = Geometry.timeUntilCircleCollision(circle, ballCircle, ballVelocity);
            if (time < timeTick)
                timeTick = time;
            newVelocity = Geometry.reflectCircle(circle.getCenter(), ball.getCenterPoint(), ball.getVelocity(), 1.0);

           /* if(circle.isATrigger())
                gizmo = circle.getGizmo();
		    else
		    gizmo = null;*/

        }
        return new CollisionDetails(timeTick, newVelocity);
    }


    public void moveBall() {
        double timeTick = 0.05;
        CollisionDetails cd = timeUntilCollision();
        double tuc = cd.getTuc();
        if (ball != null && !ball.isStopped()) {
            System.out.println(tuc);
            if (tuc > timeTick) {
                ball = moveBallForTime(ball, timeTick);
            } else {
                //fix me
                ball = moveBallForTime(ball, tuc);
                ball.setVelocity(cd.getVelocity());
            }
           // ball.setVelocity(ball.getVelocity().plus(new Vect(0, 25)));
              /*  if(!activeFlippers().isEmpty()){  // check if any flippers have been triggered
                    for(int i=0; i<activeFlippers.size();i++){
                        activeFlippers.get(i).moveFlipperForTime(timeTick); // move the flippers
                    }
                    */


           /* if (cd.getGizmo() != null) {
                cd.getGizmo().activate();
            }*/
            this.setChanged();
            this.notifyObservers();
        }
    }


    private Ball moveBallForTime(Ball ball, double time) {

        double newX = 0.0;
        double newY = 0.0;
        double xVel = ball.getVelocity().x();
        double yVel = ball.getVelocity().y();
        newX = ball.getxCoord() + (xVel * time);
        newY = ball.getyCoord() + (yVel * time);
        ball.setxCoord(newX);
        ball.setyCoord(newY);
        return ball;
    }

    public ArrayList<LineSegment> getLines() {
        return lines;
    }

    public ArrayList<Circle> getCircles() {
        return circles;
    }

    public void addLine(LineSegment lineSegment) {
        lines.add(lineSegment);
    }

    public Ball getBall() {
        return ball;
    }

    public void setBallSpeed(int x, int y) {
        ball.setVelocity(new Vect(x, y));
    }
}