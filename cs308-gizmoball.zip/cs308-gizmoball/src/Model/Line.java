package Model;

public class Line {
}
