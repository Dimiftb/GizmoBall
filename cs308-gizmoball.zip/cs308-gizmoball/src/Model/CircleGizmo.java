package Model;

import java.awt.*;

public class CircleGizmo implements IGizmo {
    private double xCoord;
    private double yCoord;
    private double radius;
    private Color colour;

    public CircleGizmo(double x, double y, double r, Color c) {
        xCoord = x;
        yCoord = y;
        radius = r;
        colour = c;

    }

    public double getxCoord() {
        return xCoord;
    }

    public double getyCoord() {
        return yCoord;
    }

    public double getRadius() {
        return radius;
    }

    public Color getColour() {
        return colour;
    }

    public void setxCoord(double xCoord) {
        this.xCoord = xCoord;
    }

    public void setyCoord(double yCoord) {
        this.yCoord = yCoord;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setColour(Color colour) {
        this.colour = colour;
    }
}
