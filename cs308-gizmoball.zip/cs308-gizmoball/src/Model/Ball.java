package Model;

import physics.Circle;
import physics.Vect;

import java.awt.*;

public class Ball {
    private double xCoord;
    private double yCoord;
    private double radius;
    private Vect velocity;
    private Color colour;
    private Boolean stopped;
    private Vect centerPoint;


    public Ball(double x, double y, double xv, double yv) {
        xCoord = x; // Centre coordinates
        yCoord = y;
        colour = Color.BLUE;
        velocity = new Vect(xv, yv);
        radius = 10;
        stopped = false;
    }

    public Circle makeCircle() {
        Circle c = new Circle(xCoord,yCoord,radius);
        centerPoint = c.getCenter();
        return c;
    }


    public double getxCoord() {
        return xCoord;
    }

    public double getyCoord() {
        return yCoord;
    }

    public double getRadius() {
        return radius;
    }

    public Vect getVelocity() {
        return velocity;
    }

    public Color getColour() {
        return colour;
    }

    public Boolean isStopped() {
        return stopped;
    }

    public void setxCoord(double xCoord) {
        this.xCoord = xCoord;
    }

    public void setyCoord(double yCoord) {
        this.yCoord = yCoord;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public void setVelocity(Vect velocity) {
        this.velocity = velocity;
    }

    public void setColour(Color colour) {
        this.colour = colour;
    }

    public void setStopped(Boolean stopped) {
        this.stopped = stopped;
    }

    public Vect getCenterPoint() {
        return centerPoint;
    }
}
