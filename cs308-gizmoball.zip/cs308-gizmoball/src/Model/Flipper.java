package Model;

import java.awt.*;

public class Flipper {

    private int xpos;
    private int ypos;
    private double angle;
    private Color colour;
    private boolean side;
    private boolean active;

    public Flipper(int x, int y, boolean leftSide) {
        xpos = x;
        ypos = y;
        this.angle = 0;
        this.side = leftSide;
        colour = Color.GREEN;
        active=true;
    }

    //Getters
    public int getX() {
        return xpos;
    }

    public int getY() {
        return ypos;
    }

    public double getAngle() {
        return angle;
    }

    public Color getColour() {
        return colour;
    }

    public boolean getSide() { return side; }

    public boolean getActive(){return active;}


    //Setters
    public void setX(int x) {
        xpos = x;
    }

    public void setY(int y) {
        ypos = y;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    public void setSide(boolean side) { this.side = side; }

    public void setActive(boolean active){this.active= true;}

}