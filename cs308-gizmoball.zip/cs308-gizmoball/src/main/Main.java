package main;

import Model.GameBoardModel;
import Model.VerticalLine;
import View.GameBoard;
import View.GameView;
import physics.LineSegment;
import physics.Vect;

public class Main {
    public static void main(String[] args) {
        GameBoardModel model = new GameBoardModel();
        //model.addLine(new LineSegment(new Vect(0,200),new Vect(400,200)));

        model.setBallSpeed(50,50);

        model.addSquareGizmos(new Square(50,90,50));
        model.addSquareGizmos(new Square(150, 200, 50));
        model.addSquareGizmos(new Square(300,100,30));
        //model.addSquareGizmos(new Square(300, 400, 60));
        model.addTriangleGizmos(new Triangle(300,400,50));
        model.addTriangleGizmos(new Triangle(200,300,30));
        model.addTriangleGizmos(new Triangle(100,370,40));
        model.addCircleGizmos(new Circle(50,300,30));
        model.addCircleGizmos(new Circle(320,200,50));
        GameView view = new GameView(model);
    }
}
