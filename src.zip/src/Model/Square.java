package Model;

public class Square extends Shape{

}
