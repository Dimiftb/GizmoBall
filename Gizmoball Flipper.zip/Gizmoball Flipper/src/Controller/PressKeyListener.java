package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import Model.Model;

public class PressKeyListener implements KeyListener {

    private Model model;

    public PressKeyListener(Model m){
        model = m;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        //No point in this
    }

    @Override
    public void keyPressed(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

}
