package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import Model.Model;

/**
 * @author Murray Wood Demonstration of MVC and MIT Physics Collisions 2014
 */

public class RunListener implements ActionListener {

	private Timer timer;
	private Model model;

	public RunListener(Model m) {
		model = m;
		timer = new Timer(50, this);
	}

	@Override
	public final void actionPerformed(final ActionEvent e) {

		if (e.getSource() == timer) {
			model.moveBall();
			/*if(model.getCollionDetails().getTuc()< 0.05){
				model.moveBall();
				try{timer.wait(2000);
					System.out.println("we have paused ");
					timer = new Timer(50,this);
					// timer.notifyAll();
				     //timer.start();
				     System.out.println("we have started the timer ");
				     model.moveBall();
					}
				catch (InterruptedException ie){
					System.out.println("Interrupted waiting for the timer ");
				}
				//model.moveBall();
			}
			*/

			//model.moveFlippers();
		} else
			switch (e.getActionCommand()) {
			case "Start":
				timer.start();
				break;
			case "Stop":
				timer.stop();
				break;
			case "Tick":
				model.moveBall();
				//model.moveFlippers();
				break;
			case "Quit":
				System.exit(0);
				break;
			}
	}
}
