package Model;

import physics.Circle;
import physics.LineSegment;

public class Triangle {
    private int xCoord;
    private int yCoord;
    private int width;
    private LineSegment top;
    private LineSegment leftSide;
    private LineSegment hypotenuse;
    private Circle topLeft;
    private Circle topRight;
    private Circle bottomLeft;

    public Triangle(int x, int y, int w){
        xCoord =x;
        yCoord = y;
        width =w;
        top =new LineSegment(x,y,x+width,y);
        leftSide = new LineSegment(x,y,x,y+width);
        hypotenuse = new LineSegment(x,y+width,x+width,y);
        topLeft = new Circle(x,y,0);
        topRight = new Circle(x+width,y,0);
        bottomLeft = new Circle(x,y+width,0);
    }

    public int getxCoord() {
        return xCoord;
    }

    public void setxCoord(int xCoord) {
        this.xCoord = xCoord;
    }

    public int getyCoord() {
        return yCoord;
    }

    public void setyCoord(int yCoord) {
        this.yCoord = yCoord;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public LineSegment getTop() {
        return top;
    }

    public void setTop(LineSegment top) {
        this.top = top;
    }

    public LineSegment getLeftSide() {
        return leftSide;
    }

    public void setLeftSide(LineSegment leftSide) {
        this.leftSide = leftSide;
    }

    public LineSegment getHypotenuse() {
        return hypotenuse;
    }

    public void setHypotenuse(LineSegment hypotenuse) {
        this.hypotenuse = hypotenuse;
    }

    public Circle getTopLeft() {
        return topLeft;
    }

    public void setTopLeft(Circle topLeft) {
        this.topLeft = topLeft;
    }

    public Circle getTopRight() {
        return topRight;
    }

    public void setTopRight(Circle topRight) {
        this.topRight = topRight;
    }

    public Circle getBottomLeft() {
        return bottomLeft;
    }

    public void setBottomLeft(Circle bottomLeft) {
        this.bottomLeft = bottomLeft;
    }
}
