package Model;

public interface IGizmo {
}
