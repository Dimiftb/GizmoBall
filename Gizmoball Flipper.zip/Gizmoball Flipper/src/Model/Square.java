package Model;

import physics.Circle;
import physics.LineSegment;

public class Square {
    private int xCoor;
    private int yCoor;
    private int width;
    private LineSegment s1;
    private LineSegment s2;
    private LineSegment s3;
    private LineSegment s4;
    private Circle c1;
    private Circle c2;
    private Circle c3;
    private Circle c4;

    public Square(int x, int y, int w){
        xCoor=x;
        yCoor=y;
        width = w;
        s1 = new LineSegment(x,y,x+width, y);
        c1 = new Circle(x,y,0);
        s2 = new LineSegment(x,y,x,y+width);
        c2 = new Circle(x+width,y,0);
        s3 = new LineSegment(x+width,y,x+width,y+width);
        c3 = new Circle(x, y+width,0);
        s4 = new LineSegment(x,y+width,x+width,y+width);
        c4 = new Circle(x+width,y+width,0);
    }

    public int getxCoor() {
        return xCoor;
    }

    public int getyCoor() {
        return yCoor;
    }

    public LineSegment getS1() {
        return s1;
    }

    public LineSegment getS2() {
        return s2;
    }

    public LineSegment getS3() {
        return s3;
    }

    public LineSegment getS4() {
        return s4;
    }

    public Circle getC1() {
        return c1;
    }

    public Circle getC2() {
        return c2;
    }

    public Circle getC3() {
        return c3;
    }

    public Circle getC4() {
        return c4;
    }

    public int getWidth(){
        return width;
    }

    public void setxCoor(int xCoor) {
        this.xCoor = xCoor;
    }

    public void setyCoor(int yCoor) {
        this.yCoor = yCoor;
    }

    public void setS1(LineSegment s1) {
        this.s1 = s1;
    }

    public void setS2(LineSegment s2) {
        this.s2 = s2;
    }

    public void setS3(LineSegment s3) {
        this.s3 = s3;
    }

    public void setS4(LineSegment s4) {
        this.s4 = s4;
    }

    public void setC1(Circle c1) {
        this.c1 = c1;
    }

    public void setC2(Circle c2) {
        this.c2 = c2;
    }

    public void setC3(Circle c3) {
        this.c3 = c3;
    }

    public void setC4(Circle c4) {
        this.c4 = c4;
    }
}
